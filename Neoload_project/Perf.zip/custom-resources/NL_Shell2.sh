cd /Users/genesisthomas/eclipse-workspace/Quantum_Neoload
/usr/local/Cellar/maven/3.6.0/bin/mvn test -DtestngXmlFile=neoload_web.xml  -Dreportium-job-name=Quantum_Neoload -Dreportium-job-number=2  -Dnl.selenium.proxy.mode=EndUserExperience -Dnl.data.exchange.url=http://localhost:7400/DataExchange/v1/Service.svc/
